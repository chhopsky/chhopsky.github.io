### Roadmap

## 0.5.0
- Support for matches with more than two participants like TFT or Battle Royales

## Unscheduled
- Ability to unschedule matches without deleting them
- Ability to update Challonge with match results
- Prepopulated layouts and visualization methods for easier setup
- Populate scripts to create layouts in broadcast packages
- Drag and drop re-arranging of matches

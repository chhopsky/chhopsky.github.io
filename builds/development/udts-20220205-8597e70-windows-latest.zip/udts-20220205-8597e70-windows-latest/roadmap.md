### Roadmap

## 0.4.0
- Signed releases (no more UAC errors!)  
- Remote control  
- Stream deck integration
- FACEIT support

## Unscheduled
- Ability to unschedule matches without deleting them
- Support for matches with more than two participants like TFT or Battle Royales
- Ability to update Challonge with match results
- Prepopulated layouts and visualization methods for easier setup
- Populate scripts to create layouts in broadcast packages
- Drag and drop re-arranging of matches

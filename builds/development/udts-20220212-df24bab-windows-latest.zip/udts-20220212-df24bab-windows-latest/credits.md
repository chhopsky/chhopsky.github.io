### Credits

## Programming
Chris "chhopsky" Pollock
Matt "Nibiria" Clendaniel
Leothechosen

## QA
CubicFoxxx
Leothechosen

## Documentation
CubicFoxxx

## Moderation
Someone  

## Feature Suggestions
CubicFoxxx
Leothechosen

## Additional Assistance
Lazuli/Kerri
heytred
Mayples

## Playtesters
Froskurinn  

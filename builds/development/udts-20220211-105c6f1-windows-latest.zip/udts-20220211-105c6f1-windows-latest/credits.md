### Credits

## Original Design / Product Manager / Project Maintainer
Chris "chhopsky" Pollock  

## Programming
Chris "chhopsky" Pollock  
Matt "Nibiria" Clendaniel  
Leothechosen  
Gia Linh Nguyen  
CubicFoxxx

## UI / UX
Chris "chhopsky" Pollock  
Nikolas Tapia  
Gia Linh Nguyen

## QA
CubicFoxxx  
Leothechosen

## Build Automation
Nikolas Tapia

## Documentation
Chris "chhopsky" Pollock  
CubicFoxxx  
Nikolas Tapia

## Moderation
Someone   

## Feature Suggestions
CubicFoxxx  
Leothechosen  
Dandro  
Prem "Estarion" Thottumkara  

## Additional Assistance
Lazuli/Kerri  
heytred  
Mayples  

## Playtesters
Froskurinn  
